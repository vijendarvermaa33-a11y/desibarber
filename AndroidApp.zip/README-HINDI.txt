DESIBARBER ANDROID APP
======================

App Name: Desibarber
Website: https://desibarber.com/
Package: com.desibarber.app

FEATURES
--------
1. Desibarber app name.
2. Large D branding app icon with Desibarber text.
3. Full-screen black/gold splash screen.
4. Website loads behind the splash.
5. Splash automatically hides after about 1.6 seconds.
6. JavaScript enabled.
7. DOM storage enabled.
8. Android back button navigates WebView history.
9. HTTP/HTTPS links remain inside the app.
10. Non-web links open using the Android system.
11. Downloads are handed to Android-supported apps.

BUILD WITH GITHUB ACTIONS
-------------------------
1. Extract this ZIP.
2. Upload all extracted files/folders to your GitHub repository.
3. Open Actions.
4. Select "Build Desibarber APK".
5. Click "Run workflow".
6. Open the completed workflow run.
7. Download artifact "Desibarber-APK".
8. Inside it you will find Desibarber.apk.

IMPORTANT
---------
This is a WebView Android app for https://desibarber.com/.
